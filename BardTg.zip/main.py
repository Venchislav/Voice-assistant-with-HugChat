from aiogram import Bot, types
from aiogram.utils import executor
from aiogram.dispatcher import Dispatcher
from config import TOKEN, BARD_API

from bardapi import Bard



bard = Bard(token=BARD_API)

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


@dp.message_handler(commands=['start'])
async def process_start_command(message: types.Message):
    await message.reply("Привет!\nЯ неофициальный бот с искуственным интелектом Google Bard!")


@dp.message_handler()
async def message(msg: types.Message):
    await bot.send_message(msg.from_user.id, bard.get_answer(msg.text)['content'])


if __name__ == '__main__':
    executor.start_polling(dp)
